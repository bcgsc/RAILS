./runRAILS.sh SARSassembly.fa reads.fa 90 0.95
