./runRAILS.sh SARSassembly.fa SARSreads.fa 90 0.95
